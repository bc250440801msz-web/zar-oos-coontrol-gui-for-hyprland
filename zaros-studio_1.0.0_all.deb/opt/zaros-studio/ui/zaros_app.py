import customtkinter as ctk
from tkinter import filedialog
import subprocess
import threading
import time
import sys
import os

sys.path.append(os.path.expanduser("~/ZarOS-Engine/core"))
from zaros_core import ZarOSCore

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class ZarOSStudio(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.engine = ZarOSCore()

        self.title("ZarOS Studio — Hyprland Control Engine")
        self.geometry("960x640")
        self.configure(fg_color="#090a0f")
        self.resizable(False, False)

        # 3-Panel Layout
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # State Variables
        self.val_gaps = 12
        self.val_round = 8
        self.val_blur = 1
        self.val_border_color = "#33ccff"
        self.current_theme_mode = "dark"

        self.build_sidebar()
        self.build_sandbox_panel()
        self.build_tabs()

        self.select_tab("profiles")

    def build_sidebar(self):
        self.sidebar = ctk.CTkFrame(self, width=200, corner_radius=0, fg_color="#10121a")
        self.sidebar.grid(row=0, column=0, sticky="nsew")

        ctk.CTkLabel(self.sidebar, text="⚡ ZarOS Studio", font=ctk.CTkFont(size=18, weight="bold"), text_color="#33ccff").pack(pady=(20, 15))

        nav = [
            ("profiles", "✨ Theme Profiles"),
            ("style", "🎨 Styling & Gaps"),
            ("display", "🖥 Displays & Hz"),
            ("inputs", "🖱 Mouse & Touchpad"),
            ("wall", "🖼 Wallpaper Sync"),
            ("vault", "🛡 Safety Vault")
        ]

        self.tab_buttons = {}
        for tab_id, label in nav:
            btn = ctk.CTkButton(self.sidebar, text=label, anchor="w", fg_color="transparent", text_color="#c5c8d4",
                                hover_color="#1c1f2e", command=lambda t=tab_id: self.select_tab(t))
            btn.pack(fill="x", padx=10, pady=3)
            self.tab_buttons[tab_id] = btn

        self.lbl_status = ctk.CTkLabel(self.sidebar, text="Online", font=ctk.CTkFont(size=11), text_color="#00ff99")
        self.lbl_status.pack(side="bottom", pady=15)

    def build_sandbox_panel(self):
        """Right Side Live Interactive Visual Sandbox"""
        self.sandbox_frame = ctk.CTkFrame(self, width=220, fg_color="#10121a", corner_radius=0)
        self.sandbox_frame.grid(row=0, column=2, sticky="nsew", padx=0, pady=0)

        ctk.CTkLabel(self.sandbox_frame, text="Live Sandbox", font=ctk.CTkFont(size=14, weight="bold"), text_color="#e0def4").pack(pady=(20, 10))

        # Dummy Desktop Container
        self.preview_container = ctk.CTkFrame(self.sandbox_frame, width=180, height=260, fg_color="#181a24", corner_radius=10)
        self.preview_container.pack(padx=15, pady=10)
        self.preview_container.pack_propagate(False)

        # Simulated Floating Window
        self.dummy_win = ctk.CTkFrame(self.preview_container, fg_color="#222533",
                                      border_width=2, border_color=self.val_border_color, corner_radius=self.val_round)
        self.dummy_win.pack(expand=True, padx=self.val_gaps, pady=self.val_gaps, fill="both")

        self.lbl_win_title = ctk.CTkLabel(self.dummy_win, text="ZarOS App\n[Preview]", font=ctk.CTkFont(size=10), text_color="#8b8ea0")
        self.lbl_win_title.pack(expand=True)

        # Buttons in Sandbox Panel
        self.btn_safe_test = ctk.CTkButton(self.sandbox_frame, text="⏱ Test (10s Safe)", fg_color="#f6c177", text_color="#10121a",
                                           font=ctk.CTkFont(weight="bold"), hover_color="#e0af68", command=self.trigger_safe_test)
        self.btn_safe_test.pack(fill="x", padx=15, pady=(25, 8))

        self.btn_save_permanent = ctk.CTkButton(self.sandbox_frame, text="💾 Save to Disk", fg_color="#00ff99", text_color="#10121a",
                                                font=ctk.CTkFont(weight="bold"), hover_color="#00cc7a", command=self.save_to_disk)
        self.btn_save_permanent.pack(fill="x", padx=15, pady=4)

    def build_tabs(self):
        self.content_container = ctk.CTkFrame(self, fg_color="#090a0f", corner_radius=0)
        self.content_container.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.content_container.grid_columnconfigure(0, weight=1)
        self.content_container.grid_rowconfigure(0, weight=1)

        self.frames = {}
        for tab_id in ["profiles", "style", "display", "inputs", "wall", "vault"]:
            f = ctk.CTkFrame(self.content_container, fg_color="transparent")
            self.frames[tab_id] = f

        self.init_tab_profiles()
        self.init_tab_style()
        self.init_tab_display()
        self.init_tab_inputs()
        self.init_tab_wall()
        self.init_tab_vault()

    def select_tab(self, name):
        for f in self.frames.values():
            f.grid_forget()
        for k, b in self.tab_buttons.items():
            if k == name:
                b.configure(fg_color="#1c1f2e", text_color="#33ccff")
            else:
                b.configure(fg_color="transparent", text_color="#c5c8d4")
        self.frames[name].grid(row=0, column=0, sticky="nsew")

    # --- 1. PROFILES TAB (WITH DARK / LIGHT SWITCH) ---
    def init_tab_profiles(self):
        tab = self.frames["profiles"]
        ctk.CTkLabel(tab, text="Desktop Personality Profiles", font=ctk.CTkFont(size=16, weight="bold"), text_color="#33ccff").pack(anchor="w", pady=(0, 10))

        # --- SYSTEM APPEARANCE CARD (DARK / LIGHT) ---
        app_box = ctk.CTkFrame(tab, fg_color="#10121a", corner_radius=8)
        app_box.pack(fill="x", pady=(0, 10))

        ctk.CTkLabel(app_box, text="System Appearance (GTK / Apps)", font=ctk.CTkFont(size=12, weight="bold"), text_color="#e0def4").pack(side="left", padx=12, pady=10)
        
        self.seg_theme = ctk.CTkSegmentedButton(app_box, values=["🌙 Dark Mode", "☀️ Light Mode"], command=self.toggle_system_theme)
        self.seg_theme.set("🌙 Dark Mode")
        self.seg_theme.pack(side="right", padx=12, pady=8)

        # --- PRESET PROFILES ---
        profiles = [
            ("Cyber Neon", "Dark vibe with cyan/lime glows & animated blur", lambda: self.apply_profile(12, 8, 1, "rgba(33ccffee) rgba(00ff99ee) 45deg", "#33ccff")),
            ("Nordic Minimal", "OLED zero gaps, sharp edges, pure performance", lambda: self.apply_profile(0, 0, 0, "rgba(595959ee)", "#595959")),
            ("Solarized Glass", "Curved clean corners (14px), soft violet glow", lambda: self.apply_profile(14, 14, 1, "rgba(c4a7e7ee) rgba(eb6f92ee) 45deg", "#c4a7e7"))
        ]

        for title, desc, action in profiles:
            card = ctk.CTkFrame(tab, fg_color="#10121a", corner_radius=8)
            card.pack(fill="x", pady=5)
            ctk.CTkLabel(card, text=title, font=ctk.CTkFont(size=13, weight="bold"), text_color="#e0def4").pack(anchor="w", padx=12, pady=(6, 0))
            ctk.CTkLabel(card, text=desc, font=ctk.CTkFont(size=10), text_color="#8b8ea0").pack(anchor="w", padx=12, pady=(0, 6))
            ctk.CTkButton(card, text="Apply Preset", width=100, height=26, fg_color="#1c1f2e", text_color="#33ccff", command=action).pack(anchor="e", padx=12, pady=(0, 6))

    def toggle_system_theme(self, choice):
        if "Dark" in choice:
            self.current_theme_mode = "dark"
            subprocess.run("gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark'", shell=True)
            self.dummy_win.configure(fg_color="#222533")
            self.lbl_win_title.configure(text_color="#8b8ea0")
            self.lbl_status.configure(text="System Dark Mode Set", text_color="#33ccff")
        else:
            self.current_theme_mode = "light"
            subprocess.run("gsettings set org.gnome.desktop.interface color-scheme 'prefer-light'", shell=True)
            self.dummy_win.configure(fg_color="#e6e9ef")
            self.lbl_win_title.configure(text_color="#222533")
            self.lbl_status.configure(text="System Light Mode Set", text_color="#f6c177")

    def apply_profile(self, gaps, rounding, blur, border_val, hex_color):
        self.val_gaps = gaps
        self.val_round = rounding
        self.val_blur = blur
        self.val_border_color = hex_color

        self.engine.run_hyprctl("general:gaps_out", gaps)
        self.engine.run_hyprctl("decoration:rounding", rounding)
        self.engine.run_hyprctl("decoration:blur:enabled", blur)
        self.engine.run_hyprctl("general:col.active_border", f"'{border_val}'")
        self.update_sandbox()

    # --- 2. STYLE TAB ---
    def init_tab_style(self):
        tab = self.frames["style"]
        ctk.CTkLabel(tab, text="Styling, Gaps & Aesthetics", font=ctk.CTkFont(size=16, weight="bold"), text_color="#00ff99").pack(anchor="w", pady=(0, 15))

        self.lbl_gaps = ctk.CTkLabel(tab, text="Outer Gaps: 12px", text_color="#8b8ea0")
        self.lbl_gaps.pack(anchor="w")
        self.sl_g = ctk.CTkSlider(tab, from_=0, to=30, number_of_steps=30, progress_color="#00ff99", command=self.on_gaps_change)
        self.sl_g.set(12)
        self.sl_g.pack(fill="x", pady=(2, 10))

        self.lbl_rnd = ctk.CTkLabel(tab, text="Corner Rounding: 8px", text_color="#8b8ea0")
        self.lbl_rnd.pack(anchor="w")
        self.sl_r = ctk.CTkSlider(tab, from_=0, to=24, number_of_steps=24, progress_color="#00ff99", command=self.on_round_change)
        self.sl_r.set(8)
        self.sl_r.pack(fill="x", pady=(2, 10))

    def on_gaps_change(self, v):
        self.val_gaps = int(v)
        self.lbl_gaps.configure(text=f"Outer Gaps: {self.val_gaps}px")
        self.engine.run_hyprctl("general:gaps_out", self.val_gaps)
        self.update_sandbox()

    def on_round_change(self, v):
        self.val_round = int(v)
        self.lbl_rnd.configure(text=f"Corner Rounding: {self.val_round}px")
        self.engine.run_hyprctl("decoration:rounding", self.val_round)
        self.update_sandbox()

    def update_sandbox(self):
        padding = max(2, min(30, self.val_gaps))
        self.dummy_win.pack_configure(padx=padding, pady=padding)
        self.dummy_win.configure(corner_radius=self.val_round, border_color=self.val_border_color)

    # --- 3. DISPLAY TAB ---
    def init_tab_display(self):
        tab = self.frames["display"]
        ctk.CTkLabel(tab, text="Display & Resolution Wizard", font=ctk.CTkFont(size=16, weight="bold"), text_color="#f6c177").pack(anchor="w", pady=(0, 15))

        monitors = self.engine.get_monitors()
        if monitors:
            m = monitors[0]
            info = f"Detected: {m.get('name', 'Display')} ({m.get('width')}x{m.get('height')} @ {int(m.get('refreshRate', 60))}Hz)"
        else:
            info = "Detected: Default Wayland Screen"

        ctk.CTkLabel(tab, text=info, font=ctk.CTkFont(weight="bold"), text_color="#e0def4").pack(anchor="w", pady=4)

        ctk.CTkLabel(tab, text="Quick Display Scale:", text_color="#8b8ea0").pack(anchor="w", pady=(10, 4))
        scale_btn = ctk.CTkSegmentedButton(tab, values=["1.0 (Native)", "1.25", "1.5"],
                                           command=lambda v: self.engine.run_hyprctl("monitor", f",highres,auto,{v.split()[0]}"))
        scale_btn.set("1.0 (Native)")
        scale_btn.pack(fill="x", pady=4)

    # --- 4. INPUTS TAB ---
    def init_tab_inputs(self):
        tab = self.frames["inputs"]
        ctk.CTkLabel(tab, text="Mouse & Touchpad Tuning", font=ctk.CTkFont(size=16, weight="bold"), text_color="#c4a7e7").pack(anchor="w", pady=(0, 15))

        sw_nat = ctk.CTkSwitch(tab, text="Natural Scroll", progress_color="#c4a7e7", command=lambda: self.engine.run_hyprctl("input:touchpad:natural_scroll", 1 if sw_nat.get() else 0))
        sw_nat.select()
        sw_nat.pack(anchor="w", pady=6)

        sw_tap = ctk.CTkSwitch(tab, text="Tap-to-Click", progress_color="#c4a7e7", command=lambda: self.engine.run_hyprctl("input:touchpad:tap-to-click", 1 if sw_tap.get() else 0))
        sw_tap.select()
        sw_tap.pack(anchor="w", pady=6)

    # --- 5. WALLPAPER TAB ---
    def init_tab_wall(self):
        tab = self.frames["wall"]
        ctk.CTkLabel(tab, text="Wallpaper & Color Extraction", font=ctk.CTkFont(size=16, weight="bold"), text_color="#eb6f92").pack(anchor="w", pady=(0, 15))

        def pick_and_sync():
            file = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.png *.jpeg")])
            if file:
                ok, palette = self.engine.set_wallpaper_and_sync(file)
                if ok and palette:
                    self.val_border_color = "#33ccff"
                    self.update_sandbox()
                    self.lbl_status.configure(text="Wallpaper & Colors Synced!", text_color="#00ff99")

        ctk.CTkButton(tab, text="Select Wallpaper & Auto-Palette", fg_color="#1c1f2e", text_color="#eb6f92", command=pick_and_sync).pack(anchor="w", pady=10)

    # --- 6. SAFETY VAULT TAB ---
    def init_tab_vault(self):
        tab = self.frames["vault"]
        ctk.CTkLabel(tab, text="System Snapshots & Backups", font=ctk.CTkFont(size=16, weight="bold"), text_color="#33ccff").pack(anchor="w", pady=(0, 15))
        ctk.CTkButton(tab, text="Create Snapshot Now", fg_color="#10121a", text_color="#00ff99", command=lambda: self.engine.create_backup()).pack(anchor="w", pady=6)
        ctk.CTkButton(tab, text="Restore Last Working Config", fg_color="#10121a", text_color="#eb6f92", command=lambda: self.engine.restore_latest_backup()).pack(anchor="w", pady=6)

    # --- FAIL-SAFE 10s ROLLBACK ENGINE ---
    def trigger_safe_test(self):
        self.engine.create_backup()
        pop = ctk.CTkToplevel(self)
        pop.title("Safety Confirmation")
        pop.geometry("340x180")
        pop.configure(fg_color="#10121a")
        pop.attributes("-topmost", True)

        lbl = ctk.CTkLabel(pop, text="Reverting in 10s...", font=ctk.CTkFont(size=14, weight="bold"), text_color="#f6c177")
        lbl.pack(pady=(20, 10))

        confirmed = [False]

        def keep():
            confirmed[0] = True
            pop.destroy()
            self.lbl_status.configure(text="Changes Kept!", text_color="#00ff99")

        ctk.CTkButton(pop, text="Keep Changes", fg_color="#00ff99", text_color="#10121a", command=keep).pack(pady=5)

        def countdown():
            for i in range(10, 0, -1):
                if confirmed[0]:
                    return
                time.sleep(1)
                try:
                    lbl.configure(text=f"Reverting in {i-1}s...")
                except Exception:
                    return
            if not confirmed[0]:
                self.engine.restore_latest_backup()
                try:
                    pop.destroy()
                except Exception:
                    pass

        threading.Thread(target=countdown, daemon=True).start()

    def save_to_disk(self):
        self.engine.create_backup()
        self.engine.save_keyword_to_file("general:gaps_out", str(self.val_gaps))
        self.engine.save_keyword_to_file("decoration:rounding", str(self.val_round))
        self.engine.save_keyword_to_file("decoration:blur:enabled", str(self.val_blur))
        self.lbl_status.configure(text="Permanently Written to Disk!", text_color="#00ff99")

if __name__ == "__main__":
    app = ZarOSStudio()
    app.mainloop()
