import customtkinter as ctk
from tkinter import filedialog
import subprocess
import threading
import time
import sys
import os

sys.path.append(os.path.expanduser("~/ZarOS-Engine/core"))
from zaros_core import ZarOSCore

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class ZarOSStudio(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.engine = ZarOSCore()

        self.title("⚡ ZarOS Studio — Hyprland Compositor & Theme Suite")
        self.geometry("1020x680")
        self.configure(fg_color="#090a0f")
        self.resizable(False, False)

        # Grid config
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # State Variables
        self.val_gaps_out = 12
        self.val_gaps_in = 6
        self.val_round = 8
        self.val_border_size = 2
        self.val_active_opacity = 1.0
        self.val_inactive_opacity = 0.85
        self.val_dim = 1
        self.val_dim_strength = 0.2
        self.val_blur = 1
        self.val_anim_speed = 5
        self.val_border_color = "#33ccff"
        self.val_border_inactive = "#313244"
        self.current_theme_mode = "dark"

        self.build_sidebar()
        self.build_sandbox_panel()
        self.build_tabs()

        self.select_tab("style")

    def build_sidebar(self):
        self.sidebar = ctk.CTkFrame(self, width=210, corner_radius=0, fg_color="#10121a")
        self.sidebar.grid(row=0, column=0, sticky="nsew")

        ctk.CTkLabel(self.sidebar, text="⚡ ZarOS Studio", font=ctk.CTkFont(size=18, weight="bold"), text_color="#33ccff").pack(pady=(20, 15))

        nav = [
            ("style", "📐 Styling & Gaps"),
            ("opacity", "🔮 Opacity & Glass"),
            ("anim", "🚀 Animations & Curves"),
            ("profiles", "✨ Theme Profiles"),
            ("display", "🖥 Displays & Scaling"),
            ("inputs", "🖱 Mouse & Touchpad"),
            ("wall", "🖼 Wallpaper Sync"),
            ("vault", "🛡 Safety Vault")
        ]

        self.tab_buttons = {}
        for tab_id, label in nav:
            btn = ctk.CTkButton(self.sidebar, text=label, anchor="w", fg_color="transparent", text_color="#c5c8d4",
                                hover_color="#1c1f2e", command=lambda t=tab_id: self.select_tab(t))
            btn.pack(fill="x", padx=10, pady=3)
            self.tab_buttons[tab_id] = btn

        self.lbl_status = ctk.CTkLabel(self.sidebar, text="Ready | Hyprland Live", font=ctk.CTkFont(size=11), text_color="#00ff99")
        self.lbl_status.pack(side="bottom", pady=15)

    def build_sandbox_panel(self):
        """Dual-Window Tiled Interactive Visual Sandbox"""
        self.sandbox_frame = ctk.CTkFrame(self, width=240, fg_color="#10121a", corner_radius=0)
        self.sandbox_frame.grid(row=0, column=2, sticky="nsew")

        ctk.CTkLabel(self.sandbox_frame, text="Live Desktop Sandbox", font=ctk.CTkFont(size=14, weight="bold"), text_color="#e0def4").pack(pady=(18, 8))

        # Simulated Desktop Wallpaper Container
        self.preview_container = ctk.CTkFrame(self.sandbox_frame, width=210, height=310, fg_color="#06070a", corner_radius=10)
        self.preview_container.pack(padx=15, pady=5)
        self.preview_container.pack_propagate(False)

        # Inner Container to reflect Outer Gaps
        self.tiled_area = ctk.CTkFrame(self.preview_container, fg_color="transparent")
        self.tiled_area.pack(expand=True, fill="both", padx=10, pady=10)

        # 1. Active Window Simulation
        self.active_win = ctk.CTkFrame(self.tiled_area, fg_color="#1e1e2e",
                                       border_width=self.val_border_size,
                                       border_color=self.val_border_color,
                                       corner_radius=self.val_round)
        self.active_win.pack(side="top", expand=True, fill="both", pady=(0, self.val_gaps_in))
        
        self.lbl_act = ctk.CTkLabel(self.active_win, text="Active Window\n[Glow / Opacity 1.0]", font=ctk.CTkFont(size=10, weight="bold"), text_color="#33ccff")
        self.lbl_act.pack(expand=True)

        # 2. Inactive Window Simulation (Shows Dimming & Inactive Opacity)
        self.inactive_win = ctk.CTkFrame(self.tiled_area, fg_color="#181825",
                                         border_width=self.val_border_size,
                                         border_color=self.val_border_inactive,
                                         corner_radius=self.val_round)
        self.inactive_win.pack(side="bottom", expand=True, fill="both", pady=(self.val_gaps_in, 0))

        self.lbl_inact = ctk.CTkLabel(self.inactive_win, text="Inactive Window\n[Dimmed]", font=ctk.CTkFont(size=10), text_color="#6c7086")
        self.lbl_inact.pack(expand=True)

        # Action Buttons
        self.btn_safe_test = ctk.CTkButton(self.sandbox_frame, text="⏱ Test (10s Safe)", fg_color="#f6c177", text_color="#10121a",
                                           font=ctk.CTkFont(weight="bold"), hover_color="#e0af68", command=self.trigger_safe_test)
        self.btn_safe_test.pack(fill="x", padx=15, pady=(20, 6))

        self.btn_save_permanent = ctk.CTkButton(self.sandbox_frame, text="💾 Save to Disk", fg_color="#00ff99", text_color="#10121a",
                                                font=ctk.CTkFont(weight="bold"), hover_color="#00cc7a", command=self.save_all_to_disk)
        self.btn_save_permanent.pack(fill="x", padx=15, pady=4)

    def build_tabs(self):
        self.content_container = ctk.CTkFrame(self, fg_color="#090a0f", corner_radius=0)
        self.content_container.grid(row=0, column=1, sticky="nsew", padx=15, pady=15)
        self.content_container.grid_columnconfigure(0, weight=1)
        self.content_container.grid_rowconfigure(0, weight=1)

        self.frames = {}
        for tab_id in ["style", "opacity", "anim", "profiles", "display", "inputs", "wall", "vault"]:
            f = ctk.CTkFrame(self.content_container, fg_color="transparent")
            self.frames[tab_id] = f

        self.init_tab_style()
        self.init_tab_opacity()
        self.init_tab_anim()
        self.init_tab_profiles()
        self.init_tab_display()
        self.init_tab_inputs()
        self.init_tab_wall()
        self.init_tab_vault()

    def select_tab(self, name):
        for f in self.frames.values():
            f.grid_forget()
        for k, b in self.tab_buttons.items():
            if k == name:
                b.configure(fg_color="#1c1f2e", text_color="#33ccff")
            else:
                b.configure(fg_color="transparent", text_color="#c5c8d4")
        self.frames[name].grid(row=0, column=0, sticky="nsew")

    # --- 1. STYLING, BORDERS & GAPS TAB ---
    def init_tab_style(self):
        tab = self.frames["style"]
        ctk.CTkLabel(tab, text="Window Layout, Borders & Geometry", font=ctk.CTkFont(size=16, weight="bold"), text_color="#33ccff").pack(anchor="w", pady=(0, 10))

        # Outer Gaps
        self.lbl_gaps_out = ctk.CTkLabel(tab, text=f"Outer Screen Gaps: {self.val_gaps_out}px", text_color="#c5c8d4")
        self.lbl_gaps_out.pack(anchor="w")
        self.sl_gaps_out = ctk.CTkSlider(tab, from_=0, to=30, number_of_steps=30, progress_color="#33ccff", command=self.on_gaps_out)
        self.sl_gaps_out.set(self.val_gaps_out)
        self.sl_gaps_out.pack(fill="x", pady=(2, 10))

        # Inner Gaps
        self.lbl_gaps_in = ctk.CTkLabel(tab, text=f"Inner Window Gaps: {self.val_gaps_in}px", text_color="#c5c8d4")
        self.lbl_gaps_in.pack(anchor="w")
        self.sl_gaps_in = ctk.CTkSlider(tab, from_=0, to=24, number_of_steps=24, progress_color="#33ccff", command=self.on_gaps_in)
        self.sl_gaps_in.set(self.val_gaps_in)
        self.sl_gaps_in.pack(fill="x", pady=(2, 10))

        # Corner Rounding Radius
        self.lbl_round = ctk.CTkLabel(tab, text=f"Window Corner Rounding: {self.val_round}px", text_color="#c5c8d4")
        self.lbl_round.pack(anchor="w")
        self.sl_round = ctk.CTkSlider(tab, from_=0, to=24, number_of_steps=24, progress_color="#00ff99", command=self.on_round)
        self.sl_round.set(self.val_round)
        self.sl_round.pack(fill="x", pady=(2, 10))

        # Border Thickness
        self.lbl_border = ctk.CTkLabel(tab, text=f"Border Thickness: {self.val_border_size}px", text_color="#c5c8d4")
        self.lbl_border.pack(anchor="w")
        self.sl_border = ctk.CTkSlider(tab, from_=0, to=6, number_of_steps=6, progress_color="#f6c177", command=self.on_border_size)
        self.sl_border.set(self.val_border_size)
        self.sl_border.pack(fill="x", pady=(2, 10))

    def on_gaps_out(self, v):
        self.val_gaps_out = int(v)
        self.lbl_gaps_out.configure(text=f"Outer Screen Gaps: {self.val_gaps_out}px")
        self.engine.run_hyprctl("general:gaps_out", self.val_gaps_out)
        self.update_sandbox()

    def on_gaps_in(self, v):
        self.val_gaps_in = int(v)
        self.lbl_gaps_in.configure(text=f"Inner Window Gaps: {self.val_gaps_in}px")
        self.engine.run_hyprctl("general:gaps_in", self.val_gaps_in)
        self.update_sandbox()

    def on_round(self, v):
        self.val_round = int(v)
        self.lbl_round.configure(text=f"Window Corner Rounding: {self.val_round}px")
        self.engine.run_hyprctl("decoration:rounding", self.val_round)
        self.update_sandbox()

    def on_border_size(self, v):
        self.val_border_size = int(v)
        self.lbl_border.configure(text=f"Border Thickness: {self.val_border_size}px")
        self.engine.run_hyprctl("general:border_size", self.val_border_size)
        self.update_sandbox()

    # --- 2. OPACITY, DIMMING & BLUR TAB ---
    def init_tab_opacity(self):
        tab = self.frames["opacity"]
        ctk.CTkLabel(tab, text="Transparency, Dimming & Glass Effects", font=ctk.CTkFont(size=16, weight="bold"), text_color="#c4a7e7").pack(anchor="w", pady=(0, 10))

        # Active Opacity
        self.lbl_act_op = ctk.CTkLabel(tab, text=f"Active Window Opacity: {self.val_active_opacity:.2f}", text_color="#c5c8d4")
        self.lbl_act_op.pack(anchor="w")
        self.sl_act_op = ctk.CTkSlider(tab, from_=0.4, to=1.0, number_of_steps=30, progress_color="#c4a7e7", command=self.on_act_op)
        self.sl_act_op.set(self.val_active_opacity)
        self.sl_act_op.pack(fill="x", pady=(2, 10))

        # Inactive Opacity
        self.lbl_inact_op = ctk.CTkLabel(tab, text=f"Inactive Window Opacity: {self.val_inactive_opacity:.2f}", text_color="#c5c8d4")
        self.lbl_inact_op.pack(anchor="w")
        self.sl_inact_op = ctk.CTkSlider(tab, from_=0.3, to=1.0, number_of_steps=35, progress_color="#c4a7e7", command=self.on_inact_op)
        self.sl_inact_op.set(self.val_inactive_opacity)
        self.sl_inact_op.pack(fill="x", pady=(2, 10))

        # Inactive Dimming Strength
        self.lbl_dim = ctk.CTkLabel(tab, text=f"Inactive Dimming Strength: {self.val_dim_strength:.2f}", text_color="#c5c8d4")
        self.lbl_dim.pack(anchor="w")
        self.sl_dim = ctk.CTkSlider(tab, from_=0.0, to=0.6, number_of_steps=30, progress_color="#eb6f92", command=self.on_dim_strength)
        self.sl_dim.set(self.val_dim_strength)
        self.sl_dim.pack(fill="x", pady=(2, 10))

        # Blur Switch
        self.sw_blur = ctk.CTkSwitch(tab, text="Enable Background Dual-Kawase Blur", progress_color="#00ff99", command=self.on_blur_toggle)
        self.sw_blur.select()
        self.sw_blur.pack(anchor="w", pady=8)

    def on_act_op(self, v):
        self.val_active_opacity = round(v, 2)
        self.lbl_act_op.configure(text=f"Active Window Opacity: {self.val_active_opacity:.2f}")
        self.engine.run_hyprctl("decoration:active_opacity", self.val_active_opacity)

    def on_inact_op(self, v):
        self.val_inactive_opacity = round(v, 2)
        self.lbl_inact_op.configure(text=f"Inactive Window Opacity: {self.val_inactive_opacity:.2f}")
        self.engine.run_hyprctl("decoration:inactive_opacity", self.val_inactive_opacity)
        self.update_sandbox()

    def on_dim_strength(self, v):
        self.val_dim_strength = round(v, 2)
        self.lbl_dim.configure(text=f"Inactive Dimming Strength: {self.val_dim_strength:.2f}")
        self.engine.run_hyprctl("decoration:dim_inactive", 1 if self.val_dim_strength > 0 else 0)
        self.engine.run_hyprctl("decoration:dim_strength", self.val_dim_strength)
        self.update_sandbox()

    def on_blur_toggle(self):
        val = 1 if self.sw_blur.get() else 0
        self.engine.run_hyprctl("decoration:blur:enabled", val)

    # --- 3. ANIMATIONS TAB ---
    def init_tab_anim(self):
        tab = self.frames["anim"]
        ctk.CTkLabel(tab, text="Window Animations & Bezier Speed", font=ctk.CTkFont(size=16, weight="bold"), text_color="#eb6f92").pack(anchor="w", pady=(0, 10))

        self.sw_anim = ctk.CTkSwitch(tab, text="Enable Smooth Window Animations", progress_color="#eb6f92", command=self.on_anim_toggle)
        self.sw_anim.select()
        self.sw_anim.pack(anchor="w", pady=(0, 10))

        self.lbl_speed = ctk.CTkLabel(tab, text=f"Animation Speed Factor: {self.val_anim_speed} (Lower = Faster)", text_color="#c5c8d4")
        self.lbl_speed.pack(anchor="w")
        self.sl_speed = ctk.CTkSlider(tab, from_=1, to=12, number_of_steps=11, progress_color="#eb6f92", command=self.on_anim_speed)
        self.sl_speed.set(self.val_anim_speed)
        self.sl_speed.pack(fill="x", pady=(2, 12))

        ctk.CTkLabel(tab, text="Animation Bezier Style:", text_color="#8b8ea0").pack(anchor="w", pady=(6, 2))
        self.seg_anim_type = ctk.CTkSegmentedButton(tab, values=["Snappy (Bouncy)", "Smooth Overshot", "Instant Crisp"], command=self.on_anim_style)
        self.seg_anim_type.set("Smooth Overshot")
        self.seg_anim_type.pack(fill="x", pady=4)

    def on_anim_toggle(self):
        val = 1 if self.sw_anim.get() else 0
        self.engine.run_hyprctl("animations:enabled", val)

    def on_anim_speed(self, v):
        self.val_anim_speed = int(v)
        self.lbl_speed.configure(text=f"Animation Speed Factor: {self.val_anim_speed} (Lower = Faster)")
        self.engine.run_hyprctl("animations:animation", f"'windows, 1, {self.val_anim_speed}, default'")

    def on_anim_style(self, choice):
        if "Snappy" in choice:
            self.engine.run_hyprctl("bezier", "zarBezier, 0.05, 0.9, 0.1, 1.1")
        elif "Smooth" in choice:
            self.engine.run_hyprctl("bezier", "zarBezier, 0.16, 1, 0.3, 1")
        else:
            self.engine.run_hyprctl("bezier", "zarBezier, 0.25, 1, 0.5, 1")
        self.engine.run_hyprctl("animations:animation", f"'windows, 1, {self.val_anim_speed}, zarBezier'")

    # --- 4. PROFILES TAB (DARK / LIGHT & PRESETS) ---
    def init_tab_profiles(self):
        tab = self.frames["profiles"]
        ctk.CTkLabel(tab, text="System Profiles & Presets", font=ctk.CTkFont(size=16, weight="bold"), text_color="#33ccff").pack(anchor="w", pady=(0, 10))

        # Dark / Light Mode Switch
        app_box = ctk.CTkFrame(tab, fg_color="#10121a", corner_radius=8)
        app_box.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(app_box, text="Global App Appearance (GTK / Qt):", font=ctk.CTkFont(size=12, weight="bold"), text_color="#e0def4").pack(side="left", padx=12, pady=10)
        self.seg_theme = ctk.CTkSegmentedButton(app_box, values=["🌙 Dark Mode", "☀️ Light Mode"], command=self.toggle_system_theme)
        self.seg_theme.set("🌙 Dark Mode")
        self.seg_theme.pack(side="right", padx=12, pady=8)

        # Presets
        presets = [
            ("Cyber Neon", "Max Glow, Violet-Cyan borders, 12px gaps", 12, 6, 8, 2, "rgba(33ccffee) rgba(00ff99ee) 45deg", "#33ccff"),
            ("Nordic OLED Minimal", "Sharp edges, 0px gaps, pure performance", 0, 0, 0, 1, "rgba(595959ee)", "#595959"),
            ("Solarized Glass", "Ultra rounded (16px), soft lavender glow", 16, 8, 16, 2, "rgba(c4a7e7ee) rgba(eb6f92ee) 45deg", "#c4a7e7")
        ]

        for title, desc, go, gi, rnd, bw, b_val, hex_c in presets:
            card = ctk.CTkFrame(tab, fg_color="#10121a", corner_radius=8)
            card.pack(fill="x", pady=4)
            ctk.CTkLabel(card, text=title, font=ctk.CTkFont(size=12, weight="bold"), text_color="#e0def4").pack(anchor="w", padx=12, pady=(6, 0))
            ctk.CTkLabel(card, text=desc, font=ctk.CTkFont(size=10), text_color="#8b8ea0").pack(anchor="w", padx=12, pady=(0, 6))
            ctk.CTkButton(card, text="Apply Preset", width=90, height=24, fg_color="#1c1f2e", text_color="#33ccff",
                          command=lambda g_o=go, g_i=gi, r=rnd, b_w=bw, bv=b_val, hx=hex_c: self.apply_preset(g_o, g_i, r, b_w, bv, hx)).pack(anchor="e", padx=12, pady=(0, 6))

    def apply_preset(self, go, gi, rnd, bw, b_val, hex_c):
        self.val_gaps_out = go
        self.val_gaps_in = gi
        self.val_round = rnd
        self.val_border_size = bw
        self.val_border_color = hex_c

        self.engine.run_hyprctl("general:gaps_out", go)
        self.engine.run_hyprctl("general:gaps_in", gi)
        self.engine.run_hyprctl("decoration:rounding", rnd)
        self.engine.run_hyprctl("general:border_size", bw)
        self.engine.run_hyprctl("general:col.active_border", f"'{b_val}'")

        # Update Sliders
        self.sl_gaps_out.set(go)
        self.sl_gaps_in.set(gi)
        self.sl_round.set(rnd)
        self.sl_border.set(bw)

        self.update_sandbox()

    def toggle_system_theme(self, choice):
        if "Dark" in choice:
            self.current_theme_mode = "dark"
            subprocess.run("gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark'", shell=True)
            self.active_win.configure(fg_color="#1e1e2e")
            self.lbl_status.configure(text="Dark Theme Active", text_color="#33ccff")
        else:
            self.current_theme_mode = "light"
            subprocess.run("gsettings set org.gnome.desktop.interface color-scheme 'prefer-light'", shell=True)
            self.active_win.configure(fg_color="#e6e9ef")
            self.lbl_status.configure(text="Light Theme Active", text_color="#f6c177")

    # --- 5. DISPLAY TAB ---
    def init_tab_display(self):
        tab = self.frames["display"]
        ctk.CTkLabel(tab, text="Display & Resolution Wizard", font=ctk.CTkFont(size=16, weight="bold"), text_color="#f6c177").pack(anchor="w", pady=(0, 15))

        monitors = self.engine.get_monitors()
        info = f"Detected: {monitors[0].get('name')} ({monitors[0].get('width')}x{monitors[0].get('height')} @ {int(monitors[0].get('refreshRate'))}Hz)" if monitors else "Detected: Default Wayland Display"
        ctk.CTkLabel(tab, text=info, font=ctk.CTkFont(weight="bold"), text_color="#e0def4").pack(anchor="w", pady=4)

        ctk.CTkLabel(tab, text="Instant Display Scaling:", text_color="#8b8ea0").pack(anchor="w", pady=(10, 4))
        scale_btn = ctk.CTkSegmentedButton(tab, values=["1.0 (Native)", "1.25", "1.5"], command=lambda v: self.engine.run_hyprctl("monitor", f",highres,auto,{v.split()[0]}"))
        scale_btn.set("1.0 (Native)")
        scale_btn.pack(fill="x", pady=4)

    # --- 6. INPUTS TAB ---
    def init_tab_inputs(self):
        tab = self.frames["inputs"]
        ctk.CTkLabel(tab, text="Trackpad & Pointer Configuration", font=ctk.CTkFont(size=16, weight="bold"), text_color="#c4a7e7").pack(anchor="w", pady=(0, 15))

        sw_nat = ctk.CTkSwitch(tab, text="Natural Scrolling", progress_color="#c4a7e7", command=lambda: self.engine.run_hyprctl("input:touchpad:natural_scroll", 1 if sw_nat.get() else 0))
        sw_nat.select()
        sw_nat.pack(anchor="w", pady=6)

        sw_tap = ctk.CTkSwitch(tab, text="Tap to Click", progress_color="#c4a7e7", command=lambda: self.engine.run_hyprctl("input:touchpad:tap-to-click", 1 if sw_tap.get() else 0))
        sw_tap.select()
        sw_tap.pack(anchor="w", pady=6)

    # --- 7. WALLPAPER SYNC TAB ---
    def init_tab_wall(self):
        tab = self.frames["wall"]
        ctk.CTkLabel(tab, text="Wallpaper Sync & Auto Color Accent", font=ctk.CTkFont(size=16, weight="bold"), text_color="#00ff99").pack(anchor="w", pady=(0, 15))

        def pick():
            f = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.png *.jpeg")])
            if f:
                ok, c = self.engine.set_wallpaper_and_sync(f)
                if ok and c:
                    self.val_border_color = c
                    self.update_sandbox()
                    self.lbl_status.configure(text=f"Synced Accent: {c}", text_color="#00ff99")

        ctk.CTkButton(tab, text="Browse Wallpaper & Sync Borders", fg_color="#1c1f2e", text_color="#00ff99", command=pick).pack(anchor="w", pady=10)

    # --- 8. SAFETY VAULT TAB ---
    def init_tab_vault(self):
        tab = self.frames["vault"]
        ctk.CTkLabel(tab, text="Snapshot Backups & System Vault", font=ctk.CTkFont(size=16, weight="bold"), text_color="#33ccff").pack(anchor="w", pady=(0, 15))
        ctk.CTkButton(tab, text="Create Safe Snapshot", fg_color="#10121a", text_color="#00ff99", command=lambda: self.engine.create_backup()).pack(anchor="w", pady=6)
        ctk.CTkButton(tab, text="Restore Last Known Working Config", fg_color="#10121a", text_color="#eb6f92", command=lambda: self.engine.restore_latest_backup()).pack(anchor="w", pady=6)

    def update_sandbox(self):
        # Outer gaps simulation
        pad_out = max(2, min(24, int(self.val_gaps_out * 0.7)))
        self.tiled_area.pack_configure(padx=pad_out, pady=pad_out)

        # Inner gaps simulation
        pad_in = max(1, min(16, int(self.val_gaps_in * 0.5)))
        self.active_win.pack_configure(pady=(0, pad_in))
        self.inactive_win.pack_configure(pady=(pad_in, 0))

        # Borders & Rounding
        self.active_win.configure(corner_radius=self.val_round, border_width=self.val_border_size, border_color=self.val_border_color)
        self.inactive_win.configure(corner_radius=self.val_round, border_width=self.val_border_size, border_color=self.val_border_inactive)

        # Inactive Dimming Simulation
        dim_hex = f"#{int(24 * (1 - self.val_dim_strength)):02x}{int(24 * (1 - self.val_dim_strength)):02x}{int(37 * (1 - self.val_dim_strength)):02x}"
        self.inactive_win.configure(fg_color=dim_hex)

    def trigger_safe_test(self):
        self.engine.create_backup()
        pop = ctk.CTkToplevel(self)
        pop.title("Rollback Protection")
        pop.geometry("320x160")
        pop.configure(fg_color="#10121a")
        pop.attributes("-topmost", True)

        lbl = ctk.CTkLabel(pop, text="Reverting in 10s...", font=ctk.CTkFont(size=14, weight="bold"), text_color="#f6c177")
        lbl.pack(pady=(20, 10))

        confirmed = [False]
        def keep():
            confirmed[0] = True
            pop.destroy()
            self.lbl_status.configure(text="Changes Confirmed", text_color="#00ff99")

        ctk.CTkButton(pop, text="Keep Changes", fg_color="#00ff99", text_color="#10121a", command=keep).pack(pady=5)

        def count():
            for i in range(10, 0, -1):
                if confirmed[0]: return
                time.sleep(1)
                try: lbl.configure(text=f"Reverting in {i-1}s...")
                except: return
            if not confirmed[0]:
                self.engine.restore_latest_backup()
                try: pop.destroy()
                except: pass
        threading.Thread(target=count, daemon=True).start()

    def save_all_to_disk(self):
        self.engine.create_backup()
        self.engine.save_keyword_to_file("general:gaps_out", str(self.val_gaps_out))
        self.engine.save_keyword_to_file("general:gaps_in", str(self.val_gaps_in))
        self.engine.save_keyword_to_file("general:border_size", str(self.val_border_size))
        self.engine.save_keyword_to_file("decoration:rounding", str(self.val_round))
        self.engine.save_keyword_to_file("decoration:active_opacity", str(self.val_active_opacity))
        self.engine.save_keyword_to_file("decoration:inactive_opacity", str(self.val_inactive_opacity))
        self.engine.save_keyword_to_file("decoration:dim_strength", str(self.val_dim_strength))
        self.engine.save_keyword_to_file("decoration:blur:enabled", str(self.val_blur))
        self.lbl_status.configure(text="Saved All Settings Permanently!", text_color="#00ff99")

if __name__ == "__main__":
    app = ZarOSStudio()
    app.mainloop()
