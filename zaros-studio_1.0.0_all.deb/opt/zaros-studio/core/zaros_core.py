import subprocess
import os
import re
import shutil
import json
import threading
import time
from datetime import datetime
from PIL import Image

CONFIG_PATH = os.path.expanduser("~/.config/hypr/hyprland.conf")
BACKUP_DIR = os.path.expanduser("~/ZarOS-Engine/backups")

class ZarOSCore:
    def __init__(self):
        os.makedirs(BACKUP_DIR, exist_ok=True)
        self.rollback_timer = None
        self.temp_backup = None

    def run_hyprctl(self, param, value):
        subprocess.run(f"hyprctl keyword {param} {value}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def dispatch(self, cmd):
        subprocess.run(f"hyprctl dispatch {cmd}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def get_monitors(self):
        """Fetch active monitor list and current scaling/resolution"""
        try:
            res = subprocess.run("hyprctl monitors -j", shell=True, capture_output=True, text=True)
            return json.loads(res.stdout)
        except Exception:
            return []

    def create_backup(self):
        if os.path.exists(CONFIG_PATH):
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            dest = os.path.join(BACKUP_DIR, f"hyprland_{ts}.conf.bak")
            shutil.copy2(CONFIG_PATH, dest)
            return dest
        return None

    def restore_latest_backup(self):
        backups = sorted([f for f in os.listdir(BACKUP_DIR) if f.endswith(".bak")])
        if backups:
            latest = os.path.join(BACKUP_DIR, backups[-1])
            shutil.copy2(latest, CONFIG_PATH)
            subprocess.run("hyprctl reload", shell=True)
            return latest
        return None

    def extract_palette(self, image_path):
        """Extract dominant accent colors from wallpaper"""
        try:
            img = Image.open(image_path).resize((100, 100))
            colors = img.getcolors(10000)
            if not colors:
                return "#33ccff", "#00ff99"
            sorted_colors = sorted(colors, key=lambda t: t[0], reverse=True)
            
            # Filter non-pure-black/white colors
            filtered = []
            for _, col in sorted_colors:
                r, g, b = col[:3]
                if 40 < (r + g + b) < 680:
                    filtered.append(f"rgba({r:02x}{g:02x}{b:02x}ee)")
                if len(filtered) == 2:
                    break

            if len(filtered) < 2:
                return "rgba(33ccffee)", "rgba(00ff99ee)"
            return filtered[0], filtered[1]
        except Exception:
            return "rgba(33ccffee)", "rgba(00ff99ee)"

    def set_wallpaper_and_sync(self, img_path):
        clean_path = os.path.abspath(os.path.expanduser(img_path))
        if not os.path.exists(clean_path):
            return False, None

        # Update hyprpaper
        hp_conf = os.path.expanduser("~/.config/hypr/hyprpaper.conf")
        with open(hp_conf, "w") as f:
            f.write(f"preload = {clean_path}\nwallpaper = ,{clean_path}\nsplash = false\nipc = on\n")
        subprocess.run(f"hyprctl hyprpaper preload '{clean_path}'", shell=True)
        subprocess.run(f"hyprctl hyprpaper wallpaper ',{clean_path}'", shell=True)

        # Extract & inject colors
        c1, c2 = self.extract_palette(clean_path)
        self.run_hyprctl("general:col.active_border", f"'{c1} {c2} 45deg'")
        return True, (c1, c2)

    def save_keyword_to_file(self, key, value):
        if not os.path.exists(CONFIG_PATH):
            return False
        with open(CONFIG_PATH, "r") as f:
            content = f.read()

        pattern = rf"(^\s*{re.escape(key)}\s*=\s*).*$"
        if re.search(pattern, content, flags=re.MULTILINE):
            new_content = re.sub(pattern, rf"\g<1>{value}", content, flags=re.MULTILINE)
        else:
            new_content = content + f"\n{key} = {value}\n"

        with open(CONFIG_PATH, "w") as f:
            f.write(new_content)
        return True
