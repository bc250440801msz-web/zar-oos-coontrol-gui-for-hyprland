import subprocess
import json
import os
import shutil
from datetime import datetime

class ZarOSCore:
    def __init__(self):
        self.config_path = os.path.expanduser("~/.config/hypr/hyprland.conf")
        self.backup_dir = os.path.expanduser("~/.config/hypr/backups")
        os.makedirs(self.backup_dir, exist_ok=True)

    def run_hyprctl(self, keyword, value):
        """Hyprland ke live memory runtime me instant keyword inject karta hai bina restart kiye"""
        cmd = f"hyprctl keyword {keyword} {value}"
        try:
            res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            return res.returncode == 0
        except Exception as e:
            print(f"Error running hyprctl: {e}")
            return False

    def create_backup(self):
        """10s Safe Mode aur snapshot rollback ke liye safe copy banata hai"""
        if os.path.exists(self.config_path):
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            b_path = os.path.join(self.backup_dir, f"hyprland_backup_{ts}.conf")
            shutil.copy2(self.config_path, b_path)
            return b_path
        return None

    def restore_latest_backup(self):
        """Fail-safe timer khatam hone par last working state wapis lata hai"""
        backups = sorted([f for f in os.listdir(self.backup_dir) if f.startswith("hyprland_backup_")])
        if backups:
            last = os.path.join(self.backup_dir, backups[-1])
            shutil.copy2(last, self.config_path)
            subprocess.run("hyprctl reload", shell=True)
            return True
        return False

    def save_keyword_to_file(self, keyword, value):
        """Permanent disk save logic (safe regex file modification)"""
        if not os.path.exists(self.config_path):
            return False
        
        with open(self.config_path, "r") as f:
            lines = f.readlines()

        updated = False
        new_lines = []
        for line in lines:
            stripped = line.strip()
            # Commented lines ko chhor kar keyword dhoondo
            if not stripped.startswith("#") and "=" in stripped:
                k, _ = stripped.split("=", 1)
                if k.strip() == keyword.strip():
                    new_lines.append(f"{keyword} = {value}\n")
                    updated = True
                    continue
            new_lines.append(line)

        if not updated:
            new_lines.append(f"\n# Injected by ZarOS Studio\n{keyword} = {value}\n")

        with open(self.config_path, "w") as f:
            f.writelines(new_lines)

        subprocess.run("hyprctl reload", shell=True)
        return True

    def get_monitors(self):
        """Wayland connected monitors ki JSON dump nikalta hai"""
        try:
            res = subprocess.run("hyprctl monitors -j", shell=True, capture_output=True, text=True)
            if res.returncode == 0 and res.stdout.strip():
                return json.loads(res.stdout)
        except Exception:
            pass
        return []

    def set_wallpaper_and_sync(self, image_path):
        """Pillow se wallpaper ka dominant color extract karke Hyprland border par set karta hai"""
        if not os.path.exists(image_path):
            return False, None
        try:
            from PIL import Image
            img = Image.open(image_path).convert('RGB').resize((64, 64))
            colors = sorted(img.getcolors(4096), key=lambda x: x[0], reverse=True)
            
            # Brightest vibrant accent color dhoondo
            accent_hex = "#33ccff"
            for count, (r, g, b) in colors:
                if (r + g + b) > 150 and not (abs(r-g) < 15 and abs(g-b) < 15):
                    accent_hex = f"#{r:02x}{g:02x}{b:02x}"
                    break

            # Swww ya hyprpaper trigger
            subprocess.run(f"swww img '{image_path}' --transition-type grow 2>/dev/null || hyprctl hyprpaper wallpaper ',{image_path}' 2>/dev/null", shell=True)
            self.run_hyprctl("general:col.active_border", f"'rgba({accent_hex.replace('#', '')}ee) rgba(33ccffee) 45deg'")
            return True, accent_hex
        except Exception as e:
            print(f"Palette Sync Error: {e}")
            return False, None
